@echo off
setlocal
chcp 936 >nul
set "PY="

:: 1) py launcher (verify it is a real python)
where py >nul 2>nul
if not errorlevel 1 (
    py -3 --version >nul 2>nul
    if not errorlevel 1 set "PY=py -3"
)

:: 2) common install paths (absolute paths, real python)
if not defined PY (
    for /d %%P in ("%LOCALAPPDATA%\Programs\Python\Python*") do (
        if exist "%%~P\python.exe" set "PY=%%~P\python.exe"
    )
)
if not defined PY (
    for /d %%P in ("C:\Python*") do (
        if exist "%%~P\python.exe" set "PY=%%~P\python.exe"
    )
)

:: 3) WorkBuddy isolated env (this machine's fallback)
if not defined PY (
    for /d %%P in ("%USERPROFILE%\.workbuddy\binaries\python\versions\*") do (
        if exist "%%~P\python.exe" set "PY=%%~P\python.exe"
    )
)

:: 4) python on PATH (verify --version to skip Microsoft Store alias)
if not defined PY (
    where python >nul 2>nul
    if not errorlevel 1 (
        python --version >nul 2>nul
        if not errorlevel 1 set "PY=python"
    )
)

if not defined PY (
    echo [FATAL] Python 3 not found. Install from https://www.python.org/downloads/
    pause
    exit /b 2
)

"%PY%" "%~dp0tool.py" %*
exit /b %errorlevel%
