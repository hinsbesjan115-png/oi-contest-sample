#include <bits/stdc++.h>
using namespace std;
#define int long long

signed main () {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    // freopen("T2.in", "r", stdin);
    // freopen("T2.out", "w", stdout);


    return 0;
}
