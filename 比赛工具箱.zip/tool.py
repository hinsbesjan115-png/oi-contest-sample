#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
比赛工具箱 —— 一键工具台引擎
================================
双击「启动.bat」进入交互式菜单（一键工具台）。

也可以用命令行直接调用：
    python tool.py duipai T1      # 对拍 T1（普通小数据）
    python tool.py selftest       # 一键自检
    python tool.py sample T1      # 只测 T1 样例
其余功能请在菜单里操作。
"""

import os
import sys
import time
import glob
import hashlib
import subprocess
import threading
import shutil

# ---- 统一 UTF-8 输出（配合启动.bat 里的 chcp 65001）----
for _s in (sys.stdout, sys.stderr):
    try:
        _s.reconfigure(encoding="gbk", errors="replace")
    except Exception:
        pass

BASE = os.path.dirname(os.path.abspath(__file__))
CODE = os.path.join(BASE, "code")
DUI = os.path.join(BASE, "对拍")
BAK = os.path.join(BASE, "备份")
SAMPLE = os.path.join(DUI, "样例")
BIG = os.path.join(DUI, "大样例")
CUR_FILE = os.path.join(BASE, "current.cfg")

PROBLEMS = ["T1", "T2", "T3", "T4"]

# 编译选项
CPP_STD = "c++17"
COMPILE_FLAGS = ["-O2", "-std=" + CPP_STD, "-Wall", "-Wno-unused-result"]

# 计时/超时
DEFAULT_TIMEOUT = 5.0        # 正解单次运行超时（秒）
BF_TIMEOUT = 8.0             # 暴力单次超时（秒）

GPP = None
BACKUP_THREAD = None
BACKUP_STOP = threading.Event()


# ============================================================
#  基础工具
# ============================================================
def p(*a):
    """带 flush 的打印，避免菜单刷新丢失。"""
    print(*a)
    sys.stdout.flush()


def read_line(prompt=""):
    try:
        if prompt:
            p(prompt)
        return input().strip()
    except (EOFError, KeyboardInterrupt):
        return ""


def ask_int(prompt, default=None):
    s = read_line(prompt)
    if s == "" and default is not None:
        return default
    try:
        return int(s)
    except ValueError:
        return None


def current_problem():
    if os.path.exists(CUR_FILE):
        with open(CUR_FILE, "r", encoding="utf-8") as f:
            v = f.read().strip()
        if v in PROBLEMS:
            return v
    return "T1"


def set_problem(t):
    with open(CUR_FILE, "w", encoding="utf-8") as f:
        f.write(t)


def md5_of(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def ts():
    return time.strftime("%Y%m%d_%H%M%S")


# ============================================================
#  编译器探测
# ============================================================
def find_gpp():
    """找 g++.exe。返回绝对路径或 None。
    找到后会把它的 bin 目录加入 PATH——g++ 运行时要加载同目录的依赖 DLL
    （libwinpthread-1.dll 等），若 bin 目录不在 PATH 里，双击 bat 时 g++ 会静默失败。"""
    global GPP
    if GPP:
        return GPP

    def _use(g):
        global GPP
        GPP = g
        bin_dir = os.path.dirname(g)
        os.environ["PATH"] = bin_dir + os.pathsep + os.environ.get("PATH", "")
        return GPP

    # 1) PATH 里的 g++
    for c in ["g++"]:
        try:
            r = subprocess.run(["where", c], capture_output=True, text=True, encoding="gbk", errors="replace")
            if r.returncode == 0:
                line = r.stdout.strip().splitlines()[0].strip()
                if line and os.path.isfile(line):
                    return _use(line)
        except Exception:
            pass

    # 2) 常见安装路径（含小熊猫C++）
    candidates = [
        r"D:\Program Files\RedPanda-Cpp\mingw64\bin\g++.exe",
        r"C:\Program Files\RedPanda-Cpp\mingw64\bin\g++.exe",
        r"C:\Program Files\CodeBlocks\MinGW\bin\g++.exe",
        r"C:\Program Files (x86)\Dev-Cpp\MinGW64\bin\g++.exe",
        r"C:\TDM-GCC-64\bin\g++.exe",
        r"C:\msys64\mingw64\bin\g++.exe",
        r"C:\msys64\ucrt64\bin\g++.exe",
        r"C:\mingw64\bin\g++.exe",
        r"C:\MinGW\bin\g++.exe",
        r"D:\mingw64\bin\g++.exe",
        r"D:\Program Files\CodeBlocks\MinGW\bin\g++.exe",
    ]
    for c in candidates:
        if os.path.isfile(c):
            return _use(c)

    # 3) 通配搜一遍 D 盘常见 IDE
    for pattern in [r"D:\Program Files*\*\mingw64\bin\g++.exe",
                    r"C:\Program Files*\*\mingw64\bin\g++.exe"]:
        for f in glob.glob(pattern):
            if os.path.isfile(f):
                return _use(f)
    return None


def need_gpp():
    if not find_gpp():
        p("[错误] 没找到 g++ 编译器。")
        p("       请安装 MinGW / TDM-GCC / Dev-C++ / 小熊猫C++，")
        p("       或修改 tool.py 里 find_gpp() 的路径列表。")
        return False
    return True


# ============================================================
#  编译
# ============================================================
def compile_cpp(src, out_exe, extra=None):
    """编译单个 cpp，返回 (成功, 错误信息)。
    编译到 .tmp 再替换，避免旧 exe 被占用时 ld 无法重写（Windows 常见）。"""
    g = find_gpp()
    if not g:
        return False, "没找到 g++"
    tmp = out_exe + ".tmp"
    try:
        os.remove(tmp)
    except OSError:
        pass
    cmd = [g] + COMPILE_FLAGS + (extra or []) + ["-o", tmp, src]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, encoding="gbk", errors="replace")
    except Exception as e:
        return False, str(e)
    if r.returncode != 0:
        try:
            os.remove(tmp)
        except OSError:
            pass
        return False, (r.stderr or r.stdout or "未知编译错误")
    # 替换旧 exe（Windows 上旧 exe 可能短暂被占用，重试几次）
    for _ in range(10):
        try:
            os.replace(tmp, out_exe)
            return True, ""
        except PermissionError:
            time.sleep(0.2)
    try:
        os.replace(tmp, out_exe)
    except Exception as e:
        return False, "替换 exe 失败: " + str(e)
    return True, ""


def run_proc(cmd, timeout=None, stdin_data=None, cwd=None):
    """运行一个程序，返回 (returncode, stdout, stderr)。"""
    try:
        r = subprocess.run(cmd, input=stdin_data, capture_output=True,
                           text=True, encoding="gbk", errors="replace",
                           timeout=timeout, cwd=cwd)
        return r.returncode, r.stdout, r.stderr
    except subprocess.TimeoutExpired:
        return "TLE", "", ""
    except Exception as e:
        return "ERR", "", str(e)


# ============================================================
#  对拍组件路径
# ============================================================
def prob_dir(t):
    return os.path.join(DUI, t)


def src_of(t, name):
    return os.path.join(prob_dir(t), name + ".cpp")


def exe_of(t, name):
    return os.path.join(prob_dir(t), name + ".exe")


def sol_src(t):
    return os.path.join(CODE, t + ".cpp")


def build_pair(t):
    """编译每题对拍必需的组件。返回 (是否成功, 错误信息)。
    组件：gen.exe / bf.exe / checker.exe / sol.exe(正解)。"""
    steps = [
        (src_of(t, "gen"), exe_of(t, "gen"), None),
        (src_of(t, "bf"), exe_of(t, "bf"), None),
        (src_of(t, "checker"), exe_of(t, "checker"), None),
        (sol_src(t), exe_of(t, "sol"), None),
    ]
    for src, out, extra in steps:
        if not os.path.exists(src):
            return False, "缺少文件: " + os.path.relpath(src, BASE)
        p("  编译 " + os.path.relpath(src, BASE) + " ...")
        ok, errmsg = compile_cpp(src, out, extra)
        if not ok:
            return False, errmsg
    return True, ""


def build_interact(t):
    for name in ["interactor", "gen"]:
        src = src_of(t, name)
        out = exe_of(t, name)
        if not os.path.exists(src):
            return False, "缺少文件: " + os.path.relpath(src, BASE)
        p("  编译 " + os.path.relpath(src, BASE) + " ...")
        ok, errmsg = compile_cpp(src, out)
        if not ok:
            return False, errmsg
    # 正解
    src = sol_src(t)
    out = exe_of(t, "sol")
    if not os.path.exists(src):
        return False, "缺少文件: " + os.path.relpath(src, BASE)
    ok, errmsg = compile_cpp(src, out)
    if not ok:
        return False, errmsg
    return True, ""


# ============================================================
#  生成数据
# ============================================================
def gen_once(t, seed, mode="normal"):
    """gen.exe <seed> <mode> -> 写 data.in。"""
    data_file = os.path.join(prob_dir(t), "data.in")
    cmd = [exe_of(t, "gen"), str(seed), mode]
    rc, out, err = run_proc(cmd, timeout=10)
    with open(data_file, "w", encoding="utf-8", newline="\n") as f:
        f.write(out)
    return data_file, rc


# ============================================================
#  功能 1/2：普通对拍 + 压力对拍（梗1 -> 暴力 vs 正解 -> checker）
# ============================================================
def do_duipai(t, mode="normal", times=None, label="普通对拍"):
    if not need_gpp():
        return
    if not os.path.exists(sol_src(t)):
        p("[错误] 找不到正解 " + os.path.relpath(sol_src(t), BASE) + "，请先写它。")
        return
    if times is None:
        times = ask_int("对拍次数（默认 100）：", 100) or 100

    p("")
    p("=== %s : %s ===" % (label, t))
    ok, errmsg = build_pair(t)
    if not ok:
        p("[编译失败]")
        p(errmsg)
        return

    d = prob_dir(t)
    data_file = os.path.join(d, "data.in")
    bf_out = os.path.join(d, "bf.out")
    sol_out = os.path.join(d, "sol.out")

    start = time.time()
    fail = None
    for i in range(1, times + 1):
        seed = int(time.time() * 1000) % (10 ** 12) + i
        # 生成数据
        rc, out, _ = run_proc([exe_of(t, "gen"), str(seed), mode], timeout=10)
        with open(data_file, "w", encoding="utf-8", newline="\n") as f:
            f.write(out)
        # 暴力
        with open(data_file, "r", encoding="utf-8") as fi, \
             open(bf_out, "w", encoding="utf-8", newline="\n") as fo:
            r = subprocess.run([exe_of(t, "bf")], stdin=fi, stdout=fo, timeout=BF_TIMEOUT)
        if r.returncode != 0:
            fail = (i, seed, "暴力运行异常(RE/TLE), 返回码 %s" % r.returncode)
            break
        # 正解
        with open(data_file, "r", encoding="utf-8") as fi, \
             open(sol_out, "w", encoding="utf-8", newline="\n") as fo:
            try:
                r = subprocess.run([exe_of(t, "sol")], stdin=fi, stdout=fo, timeout=DEFAULT_TIMEOUT)
            except subprocess.TimeoutExpired:
                fail = (i, seed, "正解超时(TLE)")
                break
        if r.returncode != 0:
            fail = (i, seed, "正解运行异常(RE), 返回码 %s" % r.returncode)
            break
        # checker 比对
        rc, _, cerr = run_proc([exe_of(t, "checker"), data_file, sol_out, bf_out], timeout=10)
        if rc != 0:
            fail = (i, seed, (cerr or "两份输出不同").strip())
            break
        # 进度
        if i % 50 == 0 or i == times:
            p("  已跑 %d/%d 轮" % (i, times))

    elapsed = time.time() - start
    p("")
    if fail is None:
        p("[OK] 全部通过：%d 轮，用时 %.1f 秒" % (times, elapsed))
    else:
        i, seed, why = fail
        p("[发现不同] 第 %d 轮（seed=%s）：%s" % (i, seed, why))
        p("  输入   : " + os.path.relpath(data_file, BASE))
        p("  暴力   : " + os.path.relpath(bf_out, BASE))
        p("  正解   : " + os.path.relpath(sol_out, BASE))
        p("  复现   : gen.exe %d %s   （重新生成同样的输入）" % (seed, mode))
        # 保存现场
        save_failure(t, seed, mode, data_file, bf_out, sol_out)


def save_failure(t, seed, mode, data_file, bf_out, sol_out):
    fd = os.path.join(prob_dir(t), "_failures")
    os.makedirs(fd, exist_ok=True)
    tag = "%s_%d_%s" % (ts(), seed, mode)
    for src, nm in [(data_file, "data.in"), (bf_out, "bf.out"), (sol_out, "sol.out")]:
        if os.path.exists(src):
            shutil.copy2(src, os.path.join(fd, "%s_%s" % (tag, nm)))
    p("  现场已存 : " + os.path.relpath(fd, BASE))


# ============================================================
#  功能 3：测时间 / TLE（梗1 最大数据 -> 正解计时）
# ============================================================
def do_timing(t, mode="tle"):
    if not need_gpp():
        return
    if not os.path.exists(sol_src(t)):
        p("[错误] 找不到正解 " + os.path.relpath(sol_src(t), BASE))
        return
    p("")
    p("=== 计时测试 : %s ===" % t)
    ok, errmsg = build_pair(t)
    if not ok:
        p("[编译失败]")
        p(errmsg)
        return
    runs = ask_int("运行次数（默认 5）：", 5) or 5
    data_file = os.path.join(prob_dir(t), "data.in")
    # 用 tle 模式生成最大数据
    seed = int(time.time() * 1000) % (10 ** 12)
    rc, out, _ = run_proc([exe_of(t, "gen"), str(seed), mode], timeout=10)
    with open(data_file, "w", encoding="utf-8", newline="\n") as f:
        f.write(out)
    p("  用 %s 模式数据（seed=%d），跑 %d 次：" % (mode, seed, runs))
    total = 0.0
    ok = True
    for i in range(1, runs + 1):
        with open(data_file, "r", encoding="utf-8") as fi:
            t0 = time.perf_counter()
            try:
                r = subprocess.run([exe_of(t, "sol")], stdin=fi, stdout=subprocess.DEVNULL,
                                   timeout=DEFAULT_TIMEOUT * 4)
            except subprocess.TimeoutExpired:
                p("  第 %d 次: TLE（超过 %.1f 秒）" % (i, DEFAULT_TIMEOUT * 4))
                ok = False
                break
            dt = (time.perf_counter() - t0) * 1000
        if r.returncode != 0:
            p("  第 %d 次: RE（返回码 %s）" % (i, r.returncode))
            ok = False
            break
        total += dt
        p("  第 %d 次: %.2f ms" % (i, dt))
    if ok:
        p("  平均: %.2f ms" % (total / runs))


# ============================================================
#  功能 4：构造题（梗2 -> 正解出方案 -> checker 验证）
# ============================================================
def do_construct(t, times=None):
    if not need_gpp():
        return
    if not os.path.exists(sol_src(t)):
        p("[错误] 找不到正解 " + os.path.relpath(sol_src(t), BASE))
        return
    if times is None:
        times = ask_int("构造测试次数（默认 50）：", 50) or 50
    p("")
    p("=== 构造题验证 : %s ===" % t)
    ok, errmsg = build_pair(t)
    if not ok:
        p("[编译失败]")
        p(errmsg)
        return
    d = prob_dir(t)
    data_file = os.path.join(d, "data.in")
    sol_out = os.path.join(d, "sol.out")
    fail = None
    for i in range(1, times + 1):
        seed = int(time.time() * 1000) % (10 ** 12) + i
        rc, out, _ = run_proc([exe_of(t, "gen"), str(seed), "normal"], timeout=10)
        with open(data_file, "w", encoding="utf-8", newline="\n") as f:
            f.write(out)
        with open(data_file, "r", encoding="utf-8") as fi, \
             open(sol_out, "w", encoding="utf-8", newline="\n") as fo:
            try:
                r = subprocess.run([exe_of(t, "sol")], stdin=fi, stdout=fo, timeout=DEFAULT_TIMEOUT)
            except subprocess.TimeoutExpired:
                fail = (i, seed, "正解超时(TLE)")
                break
        if r.returncode != 0:
            fail = (i, seed, "正解运行异常(RE), 返回码 %s" % r.returncode)
            break
        # checker <input> <方案输出>  （构造题无标准答案）
        rc, _, cerr = run_proc([exe_of(t, "checker"), data_file, sol_out, "-"], timeout=10)
        if rc != 0:
            fail = (i, seed, (cerr or "构造方案不合法").strip())
            break
        if i % 50 == 0 or i == times:
            p("  已验 %d/%d 个" % (i, times))
    p("")
    if fail is None:
        p("[OK] %d 个构造全部通过" % times)
    else:
        i, seed, why = fail
        p("[构造失败] 第 %d 个（seed=%s）：%s" % (i, seed, why))
        p("  输入 : " + os.path.relpath(data_file, BASE))
        p("  输出 : " + os.path.relpath(sol_out, BASE))


# ============================================================
#  功能 5：边界测试（梗2/edge -> 正解，检测 RE/TLE）
# ============================================================
def do_edge(t, with_bf=False):
    if not need_gpp():
        return
    if not os.path.exists(sol_src(t)):
        p("[错误] 找不到正解 " + os.path.relpath(sol_src(t), BASE))
        return
    p("")
    p("=== 边界测试 : %s ===" % t)
    ok, errmsg = build_pair(t)
    if not ok:
        p("[编译失败]")
        p(errmsg)
        return
    d = prob_dir(t)
    data_file = os.path.join(d, "data.in")
    bf_out = os.path.join(d, "bf.out")
    sol_out = os.path.join(d, "sol.out")
    cases = ask_int("边界测试次数（默认 30）：", 30) or 30
    re_cnt = tle_cnt = wa_cnt = 0
    for i in range(1, cases + 1):
        seed = int(time.time() * 1000) % (10 ** 12) + i
        rc, out, _ = run_proc([exe_of(t, "gen"), str(seed), "edge"], timeout=10)
        with open(data_file, "w", encoding="utf-8", newline="\n") as f:
            f.write(out)
        # 正解
        with open(data_file, "r", encoding="utf-8") as fi, \
             open(sol_out, "w", encoding="utf-8", newline="\n") as fo:
            try:
                r = subprocess.run([exe_of(t, "sol")], stdin=fi, stdout=fo, timeout=DEFAULT_TIMEOUT)
            except subprocess.TimeoutExpired:
                tle_cnt += 1
                p("  [TLE] 第 %d 个（seed=%d）" % (i, seed))
                continue
        if r.returncode != 0:
            re_cnt += 1
            p("  [RE] 第 %d 个（seed=%d）返回码 %s" % (i, seed, r.returncode))
            continue
        # 可选：和暴力比对
        if with_bf:
            with open(data_file, "r", encoding="utf-8") as fi, \
                 open(bf_out, "w", encoding="utf-8", newline="\n") as fo:
                subprocess.run([exe_of(t, "bf")], stdin=fi, stdout=fo, timeout=BF_TIMEOUT)
            rc, _, cerr = run_proc([exe_of(t, "checker"), data_file, sol_out, bf_out], timeout=10)
            if rc != 0:
                wa_cnt += 1
                p("  [WA] 第 %d 个（seed=%d）" % (i, seed))
    p("")
    p("[边界测试结束] 共 %d 个：RE %d 个，TLE %d 个，WA %d 个" % (cases, re_cnt, tle_cnt, wa_cnt))


# ============================================================
#  功能 6：交互题（interactor vs 正解）
# ============================================================
def do_interact(t):
    if not need_gpp():
        return
    if not os.path.exists(sol_src(t)):
        p("[错误] 找不到正解 " + os.path.relpath(sol_src(t), BASE))
        return
    p("")
    p("=== 交互题测试 : %s ===" % t)
    ok, errmsg = build_interact(t)
    if not ok:
        p("[编译失败]")
        p(errmsg)
        return
    cases = ask_int("交互测试次数（默认 20）：", 20) or 20
    d = prob_dir(t)
    case_file = os.path.join(d, "case.in")
    ac = 0
    for i in range(1, cases + 1):
        seed = int(time.time() * 1000) % (10 ** 12) + i
        rc, out, _ = run_proc([exe_of(t, "gen"), str(seed), "normal"], timeout=10)
        with open(case_file, "w", encoding="utf-8", newline="\n") as f:
            f.write(out)
        verdict = run_interactive([exe_of(t, "interactor"), case_file], [exe_of(t, "sol")])
        if verdict == 0:
            ac += 1
        else:
            p("  [失败] 第 %d 个（seed=%d）interactor 返回 %s" % (i, seed, verdict))
        if i % 20 == 0:
            p("  已测 %d/%d" % (i, cases))
    p("")
    p("[交互测试结束] %d/%d 通过" % (ac, cases))


def _bridge(src, dst):
    """把一个流搬到另一个流，直到 EOF。
    用 read1 而不是 read：read(n) 会阻塞等读满 n 字节，交互/通信只有几个字节时会死锁。"""
    try:
        while True:
            chunk = src.read1(65536)
            if not chunk:
                break
            dst.write(chunk)
            dst.flush()
    except (BrokenPipeError, ValueError, OSError, AttributeError):
        pass
    finally:
        try:
            dst.close()
        except Exception:
            pass


def run_interactive(inter_cmd, sol_cmd):
    """双向连接 interactor 和 sol。返回 interactor 的退出码。"""
    sol = subprocess.Popen(sol_cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                           stderr=subprocess.DEVNULL)
    inter = subprocess.Popen(inter_cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                             stderr=subprocess.DEVNULL)
    # sol.stdin <- inter.stdout ; sol.stdout -> inter.stdin
    t1 = threading.Thread(target=_bridge, args=(inter.stdout, sol.stdin))
    t2 = threading.Thread(target=_bridge, args=(sol.stdout, inter.stdin))
    t1.start()
    t2.start()
    sol.wait()
    inter.wait()
    t1.join(timeout=1)
    t2.join(timeout=1)
    return inter.returncode


# ============================================================
#  功能 7：通信题（comm_a vs comm_b）
# ============================================================
def do_communicate(t):
    if not need_gpp():
        return
    p("")
    p("=== 通信题测试 : %s ===" % t)
    a_src = os.path.join(DUI, "comm_a.cpp")
    b_src = os.path.join(DUI, "comm_b.cpp")
    for src in [a_src, b_src]:
        if not os.path.exists(src):
            p("[错误] 缺少 " + os.path.relpath(src, BASE))
            return
    a_exe = os.path.join(DUI, "comm_a.exe")
    b_exe = os.path.join(DUI, "comm_b.exe")
    for src, out in [(a_src, a_exe), (b_src, b_exe)]:
        p("  编译 " + os.path.relpath(src, BASE) + " ...")
        ok, errmsg = compile_cpp(src, out)
        if not ok:
            p("[编译失败]")
            p(errmsg)
            return
    p("  运行 comm_a vs comm_b ...")
    a = subprocess.Popen([a_exe], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                         stderr=subprocess.DEVNULL)
    b = subprocess.Popen([b_exe], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                         stderr=subprocess.DEVNULL)
    t1 = threading.Thread(target=_bridge, args=(a.stdout, b.stdin))
    t2 = threading.Thread(target=_bridge, args=(b.stdout, a.stdin))
    t1.start()
    t2.start()
    a.wait(timeout=10)
    b.wait(timeout=10)
    t1.join(timeout=1)
    t2.join(timeout=1)
    p("  comm_a 返回码: %s" % a.returncode)
    p("  comm_b 返回码: %s" % b.returncode)
    p("  （双方返回码都为 0 通常表示通过；具体以题目协议为准）")


# ============================================================
#  功能 8：样例测试 / 大样例测试
# ============================================================
def _sample_test(t, base_dir, label):
    if not need_gpp():
        return
    if not os.path.exists(sol_src(t)):
        p("[错误] 找不到正解 " + os.path.relpath(sol_src(t), BASE))
        return
    sd = base_dir
    in_files = sorted(glob.glob(os.path.join(sd, t + "_*.in")))
    if not in_files:
        p("[提示] %s 下没有 %s_*.in 样例文件（命名：题号_编号.in，如 T1_1.in）。" % (os.path.relpath(sd, BASE), t))
        return
    p("")
    p("=== %s : %s ===" % (label, t))
    ok, errmsg = compile_cpp(sol_src(t), exe_of(t, "sol"))
    if not ok:
        p("[编译失败]")
        p(errmsg)
        return
    ok, errmsg = compile_cpp(src_of(t, "checker"), exe_of(t, "checker"))
    if not ok:
        p("[编译失败] checker")
        p(errmsg)
        return
    passed = 0
    for inf in in_files:
        base = inf[:-3]  # 去掉 .in
        # 找答案文件：.out / .ans
        ans = None
        for ext in [".out", ".ans", ".txt"]:
            if os.path.exists(base + ext):
                ans = base + ext
                break
        name = os.path.basename(inf)
        if ans is None:
            # 没答案：只跑，看是否 RE
            with open(inf, "r", encoding="utf-8") as fi:
                try:
                    r = subprocess.run([exe_of(t, "sol")], stdin=fi, stdout=subprocess.DEVNULL,
                                       timeout=DEFAULT_TIMEOUT)
                except subprocess.TimeoutExpired:
                    p("  [TLE] %s" % name)
                    continue
            if r.returncode == 0:
                p("  [OK ] %s（无答案，仅验证能运行）" % name)
                passed += 1
            else:
                p("  [RE ] %s（返回码 %s）" % (name, r.returncode))
        else:
            out_file = os.path.join(prob_dir(t), "sample_out.tmp")
            with open(inf, "r", encoding="utf-8") as fi, \
                 open(out_file, "w", encoding="utf-8", newline="\n") as fo:
                try:
                    r = subprocess.run([exe_of(t, "sol")], stdin=fi, stdout=fo, timeout=DEFAULT_TIMEOUT)
                except subprocess.TimeoutExpired:
                    p("  [TLE] %s" % name)
                    continue
            if r.returncode != 0:
                p("  [RE ] %s（返回码 %s）" % (name, r.returncode))
                continue
            rc, _, cerr = run_proc([exe_of(t, "checker"), inf, out_file, ans], timeout=10)
            if rc == 0:
                p("  [OK ] %s" % name)
                passed += 1
            else:
                p("  [WA ] %s" % name)
    p("[%s结束] %d/%d 通过" % (label, passed, len(in_files)))


def do_sample(t):
    _sample_test(t, SAMPLE, "样例测试")


def do_big(t):
    _sample_test(t, BIG, "大样例测试")


def do_sample_all():
    for t in PROBLEMS:
        _sample_test(t, SAMPLE, "样例测试")


# ============================================================
#  功能 9/10：编译 / 自检
# ============================================================
def do_compile_only(t):
    if not need_gpp():
        return
    src = sol_src(t)
    if not os.path.exists(src):
        p("[错误] 找不到 " + os.path.relpath(src, BASE))
        return
    ok, errmsg = compile_cpp(src, exe_of(t, "sol"))
    if ok:
        p("[OK] %s 编译通过" % t)
    else:
        p("[编译失败] %s" % t)
        p(errmsg)


def do_selftest():
    p("")
    p("================ 一键自检 ================")
    g = find_gpp()
    if g:
        p("[OK] 编译器: " + g)
        r = run_proc([g, "--version"], timeout=10)
        line = (r[1] or "").splitlines()
        if line:
            p("     " + line[0])
    else:
        p("[错误] 没找到 g++")
    p("")
    p("code 目录（应有 %d 个文件）：" % len(PROBLEMS))
    for t in PROBLEMS:
        f = sol_src(t)
        if os.path.exists(f):
            p("  [OK] %s.cpp" % t)
        else:
            p("  [缺] %s.cpp" % t)
    p("")
    p("对拍组件：")
    for t in PROBLEMS:
        missing = [n for n in ["gen", "bf", "checker", "interactor"]
                   if not os.path.exists(src_of(t, n))]
        if missing:
            p("  [缺] %s 缺少: %s" % (t, ", ".join(missing)))
        else:
            p("  [OK] %s 组件齐全" % t)
    p("")
    if g:
        p("编译检查（-fsyntax-only，只查语法不生成 exe）：")
        all_ok = True
        cpp_files = [sol_src(t) for t in PROBLEMS]
        cpp_files += [os.path.join(DUI, "comm_a.cpp"), os.path.join(DUI, "comm_b.cpp")]
        for t in PROBLEMS:
            for n in ["gen", "bf", "checker", "interactor"]:
                cpp_files.append(src_of(t, n))
        for f in cpp_files:
            if not os.path.exists(f):
                continue
            r = subprocess.run([g, "-std=" + CPP_STD, "-fsyntax-only", f],
                               capture_output=True, text=True, encoding="gbk", errors="replace")
            if r.returncode == 0:
                p("  [OK] " + os.path.relpath(f, BASE))
            else:
                p("  [失败] " + os.path.relpath(f, BASE))
                p((r.stderr or "")[:800])
                all_ok = False
        p("")
        p("编译检查：" + ("全部通过" if all_ok else "有失败，见上"))
    p("===========================================")


# ============================================================
#  功能 11：手动运行正解
# ============================================================
def do_manual(t):
    if not need_gpp():
        return
    src = sol_src(t)
    if not os.path.exists(src):
        p("[错误] 找不到 " + os.path.relpath(src, BASE))
        return
    ok, errmsg = compile_cpp(src, exe_of(t, "sol"))
    if not ok:
        p("[编译失败]")
        p(errmsg)
        return
    p("运行正解（%s）。请直接粘贴输入，结束按 Ctrl+Z 再回车：" % t)
    r = subprocess.run([exe_of(t, "sol")], stdin=None, stdout=None, stderr=None)
    p("")
    p("[运行结束] 返回码 %s" % r.returncode)


# ============================================================
#  自动备份
# ============================================================
def backup_daemon(interval=10):
    """后台线程：定期检查 code/*.cpp，内容变化就备份。"""
    last = {}
    p("[备份] 自动备份已启动（每 %d 秒检查一次，代码变化才备份）" % interval)
    while not BACKUP_STOP.is_set():
        try:
            for t in PROBLEMS:
                f = sol_src(t)
                if not os.path.exists(f):
                    continue
                h = md5_of(f)
                if t not in last or last[t] != h:
                    last[t] = h
                    do_backup_one(t)
        except Exception as e:
            p("[备份] 出错：" + str(e))
        BACKUP_STOP.wait(interval)
    p("[备份] 已停止。")


def do_backup_one(t):
    os.makedirs(BAK, exist_ok=True)
    src = sol_src(t)
    if not os.path.exists(src):
        return
    dst = os.path.join(BAK, "%s_%s.cpp" % (t, ts()))
    shutil.copy2(src, dst)
    # 记录日志
    log_file = os.path.join(BAK, "备份日志.txt")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write("%s  %s  （%s 行）\n" % (ts(), os.path.basename(dst), line_count(src)))
    p("[备份] %s -> %s" % (t, os.path.basename(dst)))


def line_count(path):
    try:
        with open(path, "r", encoding="gbk", errors="replace") as f:
            return sum(1 for _ in f)
    except Exception:
        return 0


def start_backup():
    global BACKUP_THREAD
    if BACKUP_THREAD and BACKUP_THREAD.is_alive():
        p("[提示] 自动备份已经在运行。")
        return
    BACKUP_STOP.clear()
    BACKUP_THREAD = threading.Thread(target=backup_daemon, args=(10,), daemon=True)
    BACKUP_THREAD.start()


def stop_backup():
    global BACKUP_THREAD
    if BACKUP_THREAD and BACKUP_THREAD.is_alive():
        BACKUP_STOP.set()
        BACKUP_THREAD.join(timeout=2)
    else:
        p("[提示] 自动备份未在运行。")


def browse_backup():
    os.makedirs(BAK, exist_ok=True)
    files = sorted(glob.glob(os.path.join(BAK, "*.cpp")), reverse=True)
    if not files:
        p("[提示] 还没有备份文件。")
        return
    p("")
    p("备份列表（新的在前，共 %d 份）：" % len(files))
    for i, f in enumerate(files[:30], 1):
        p("  [%2d] %s" % (i, os.path.basename(f)))
    if len(files) > 30:
        p("  ... 还有 %d 份" % (len(files) - 30))
    p("")
    choice = read_line("输入编号可恢复到对应题目，直接回车返回：")
    if choice == "":
        return
    try:
        idx = int(choice)
        if 1 <= idx <= len(files):
            f = files[idx - 1]
            name = os.path.basename(f)
            # 文件名形如 T1_20260813_203000.cpp
            t = name.split("_")[0]
            if t not in PROBLEMS:
                p("[错误] 无法从文件名判断题目：" + name)
                return
            shutil.copy2(f, sol_src(t))
            p("[OK] 已恢复 %s -> %s" % (name, t + ".cpp"))
        else:
            p("[错误] 编号无效")
    except ValueError:
        p("[错误] 输入无效")


def snapshot_all():
    p("")
    for t in PROBLEMS:
        do_backup_one(t)
    p("[OK] 已手动快照 4 份代码。")


# ============================================================
#  菜单
# ============================================================
def switch_problem():
    p("")
    for i, t in enumerate(PROBLEMS, 1):
        mark = "（当前）" if t == current_problem() else ""
        p("  [%d] %s %s" % (i, t, mark))
    c = read_line("选择题号（1-4）：")
    m = {"1": "T1", "2": "T2", "3": "T3", "4": "T4"}
    if c in m:
        set_problem(m[c])
        p("[OK] 当前题目已切换为 %s" % m[c])
        return m[c]
    p("[提示] 未切换。")
    return current_problem()


def open_basic_files():
    base = os.path.join(BASE, "基础文件")
    for name in ["草稿纸.txt", "比赛记录.txt", "思维链.txt"]:
        f = os.path.join(base, name)
        if not os.path.exists(f):
            open(f, "w", encoding="utf-8").close()
    try:
        os.startfile(base)
    except Exception:
        p("基础文件目录: " + base)


# ============================================================
#  命令行入口
# ============================================================
def cli(argv):
    if not argv:
        p("这是引擎内部文件。请双击「启动.bat」看总目录，或直接双击 对拍 目录下的功能 bat。")
        return
    cmd = argv[0].lower()
    # 第二个参数可选：指定题目（如 T2），默认用 current.cfg 里的当前题目
    t = argv[1].upper() if len(argv) > 1 and argv[1].upper() in PROBLEMS else current_problem()

    if cmd == "duipai":          # 普通对拍
        do_duipai(t, "normal")
    elif cmd == "pressure":      # 压力对拍
        do_duipai(t, "pressure")
    elif cmd == "timing":        # 测时间 / TLE
        do_timing(t, "tle")
    elif cmd == "construct":     # 构造题验证
        do_construct(t)
    elif cmd == "edge":          # 边界测试（测 RE/TLE）
        do_edge(t, with_bf=False)
    elif cmd == "edgebf":        # 边界对拍（边界数据 + 暴力比对）
        do_edge(t, with_bf=True)
    elif cmd == "interact":      # 交互题
        do_interact(t)
    elif cmd == "communicate":   # 通信题
        do_communicate(t)
    elif cmd == "sample":        # 样例测试
        do_sample(t)
    elif cmd == "big":           # 大样例测试
        do_big(t)
    elif cmd == "compile":       # 只编译正解
        do_compile_only(t)
    elif cmd == "selftest":      # 一键自检
        do_selftest()
    elif cmd == "backup":        # 开始比赛·自动备份（常驻，Ctrl+C 停止）
        start_backup()
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            stop_backup()
    elif cmd == "browse":        # 翻阅/恢复备份
        browse_backup()
    elif cmd == "snapshot":      # 手动快照
        snapshot_all()
    elif cmd == "switch":        # 切换题目
        switch_problem()
    elif cmd == "manual":        # 手动运行
        do_manual(t)
    else:
        menu()


if __name__ == "__main__":
    cli(sys.argv[1:])
