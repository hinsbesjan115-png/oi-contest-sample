@echo off
chcp 936 >nul
cd /d "%~dp0"
call "..\_python.bat" timing
pause
