// ============================================================
//  checker.cpp —— 校验器
//  用法：checker.exe <输入> <输出1> <输出2>
//  返回：0 = 通过；1 = 不通过；2 = 尚未配置
//
//  普通对拍：输出1 = 正解，输出2 = 暴力，按 token 比较。
//  构造题  ：输出2 传 "-"，请补写合法性检查（验证「输出1」是否合法）。
// ============================================================
#include <bits/stdc++.h>
using namespace std;

vector<string> ReadTokens (const string &file) {
    ifstream fin(file);
    vector<string> v;
    string s;
    while (fin >> s) v.push_back(s);
    return v;
}

int main (int argc, char *argv[]) {
    if (argc < 3) {
        cerr << "参数不足\n";
        return 2;
    }
    string input = argv[1], out1 = argv[2], out2 = (argc >= 4 ? argv[3] : "");

    // ---------- 普通对拍：token 比较 ----------
    if (!out2.empty() && out2 != "-") {
        auto a = ReadTokens(out1);
        auto b = ReadTokens(out2);

        // 答案顺序无关的题，取消下面两行注释：
        // sort(a.begin(), a.end());
        // sort(b.begin(), b.end());

        if (a == b) return 0;
        if (a.size() != b.size()) {
            cerr << "token 数量不同: " << a.size() << " vs " << b.size() << "\n";
            return 1;
        }
        for (size_t i = 0; i < a.size(); i++) {
            if (a[i] != b[i]) {
                cerr << "第 " << (i + 1) << " 个 token: '" << a[i] << "' vs '" << b[i] << "'\n";
                return 1;
            }
        }
        return 0;
    }

    // ---------- 构造题：验证方案 ----------
    // 读 input（题目输入）和 out1（你的构造方案），检查是否合法。
    // 合法 return 0；不合法 cerr << 原因; return 1。
    // ============================================================
    cerr << "构造题请先在 checker.cpp 里补合法性检查。\n";
    return 2;
}
