// ============================================================
//  interactor.cpp —— 交互题评测器（模拟器）
//  用法：interactor.exe <case_file>
//  case_file 由 gen.cpp 生成（隐藏数据）。
//  本程序 stdin/stdout 会被工具与正解双向连接：
//     你 cout 问询  -> 选手读到
//     选手 cout 回答 -> 你 cin 读到
//  每次输出问询后必须 flush（endl 或 cout.flush()）。
//  返回：0 = 通过；1 = 选手答错；2 = 尚未配置
// ============================================================
#include <bits/stdc++.h>
using namespace std;

int main (int argc, char *argv[]) {
    if (argc < 2) {
        cerr << "缺少 case_file\n";
        return 2;
    }
    ifstream fin(argv[1]);

    // ============================================================
    //  示例骨架（猜数题）：把隐藏答案从 fin 读进来，与选手对话。
    //    int hidden; fin >> hidden;
    //    while (true) {
    //        string op; int x;
    //        if (!(cin >> op)) return 1;          // 选手提前退出 = 错
    //        if (op == "?") {
    //            cin >> x;
    //            cout << (x < hidden ? 1 : (x > hidden ? -1 : 0)) << endl;
    //        } else if (op == "!") {
    //            cin >> x;
    //            return x == hidden ? 0 : 1;      // 0 通过 / 1 答错
    //        }
    //    }
    // ============================================================

    cerr << "interactor 还是模板，请按题目通信协议补全。\n";
    return 2;
}
