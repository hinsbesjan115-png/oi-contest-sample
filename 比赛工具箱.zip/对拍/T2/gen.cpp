// ============================================================
//  gen.cpp —— 数据生成器（梗）
//  用法：gen.exe <seed> <mode>
//    mode:
//      normal   随机小数据（普通对拍，n 小）
//      pressure 压力数据（压力对拍，n 较大）
//      tle      卡时间数据（测时间，n 开到题目上限）
//      edge     边界数据（0/1/MAX/重复/递增递减，测 RE/WA）
//  同一个 seed + mode 必须产生固定数据，失败后才能一键复现。
// ============================================================
#include <bits/stdc++.h>
using namespace std;
#define int long long

mt19937_64 rnd;

int Rand (int l, int r) {
    return uniform_int_distribution<int>(l, r)(rnd);
}

bool RandBool () { return Rand(0, 1); }

template <class T>
T RandPick (const vector<T> &v) {
    return v[Rand(0, (int)v.size() - 1)];
}

// 随机排列 1..n
vector<int> RandPerm (int n) {
    vector<int> p(n);
    iota(p.begin(), p.end(), 1);
    shuffle(p.begin(), p.end(), rnd);
    return p;
}

// 随机字符串
string RandStr (int len, const string &chars = "abcdefghijklmnopqrstuvwxyz") {
    string s;
    s.reserve(len);
    for (int i = 0; i < len; i++) s += chars[Rand(0, (int)chars.size() - 1)];
    return s;
}

// 随机树：n 个点，输出 n-1 条边（按需可加权值）
vector<pair<int,int>> RandTree (int n) {
    vector<pair<int,int>> e;
    for (int i = 2; i <= n; i++) e.push_back({Rand(1, i - 1), i});
    shuffle(e.begin(), e.end(), rnd);
    return e;
}

signed main (signed argc, char *argv[]) {
    unsigned long long seed = chrono::steady_clock::now().time_since_epoch().count();
    if (argc >= 2) seed = stoull(argv[1]);
    string mode = (argc >= 3 ? argv[2] : "normal");
    rnd.seed(seed);

    // ============================================================
    //  【只需要改这里】按当前题目写数据生成器。
    //  根据 mode 决定规模；edge 要专门构造贴边界的数据。
    // ============================================================
    int n;
    if (mode == "normal") n = Rand(1, 20);
    else if (mode == "pressure") n = Rand(1000, 10000);
    else if (mode == "tle") n = 200000;
    else n = Rand(1, 5);   // edge：先给个小边界示例，按题目改

    // 示例：输出 n 个 [1, 1e9] 的数
    cout << n << '\n';
    for (int i = 1; i <= n; i++) cout << Rand(1, 1000000000LL) << " \n"[i == n];

    return 0;
}
