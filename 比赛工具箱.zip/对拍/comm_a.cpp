// ============================================================
//  comm_a.cpp —— 通信题 A 方
//  与 comm_b.cpp 双向通信：你 cout 输出会发给 B，cin 读 B 发来的。
//  每次输出后必须 flush（endl）。
//  返回 0 = 通过；非 0 = 失败（具体以题目协议为准）。
// ============================================================
#include <bits/stdc++.h>
using namespace std;

int main () {
    // 示例：A 发 "ping"，读 B 回 "pong"。
    cout << "ping" << endl;
    string s;
    cin >> s;
    return s == "pong" ? 0 : 1;
}
