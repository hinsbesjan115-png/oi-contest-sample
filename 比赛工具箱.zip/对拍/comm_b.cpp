// ============================================================
//  comm_b.cpp —— 通信题 B 方
//  与 comm_a.cpp 双向通信：cout 输出发给 A，cin 读 A 发来的。
//  每次输出后必须 flush（endl）。
// ============================================================
#include <bits/stdc++.h>
using namespace std;

int main () {
    // 示例：读 A 发的 "ping"，回 "pong"。
    string s;
    cin >> s;
    cout << "pong" << endl;
    return s == "ping" ? 0 : 1;
}
