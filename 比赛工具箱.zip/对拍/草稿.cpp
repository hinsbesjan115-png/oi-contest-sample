#include <bits/stdc++.h>
using namespace std;
#define int long long

// 草稿：随手试一个想法、测个语法、跑个样例。
signed main () {
    ios::sync_with_stdio(false);
    cin.tie(0);



    return 0;
}
